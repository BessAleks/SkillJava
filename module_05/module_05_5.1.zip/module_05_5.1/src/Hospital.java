import java.text.DecimalFormat;
import java.util.Arrays;

public class Hospital {
    public static void main(String[] args) {
        int id = 1;
        int kd = 0;
        double sumTemperature = 0;
        double sumAve;
        double [] patient = new double[30];
        for (int i = 0; i < patient.length; i++){
            patient[i] = ((double)(Math.random() * 8) + 32);
            //System.out.println("Температура пациента " + id + ": "+ patient[i] + " градусов.");
            id++;
        }

        System.out.println("Список температуры больных: " + Arrays.toString(patient).replaceAll("\\[", "").replaceAll("\\]", ""));// Печать массива в строку

        for (int j = 0; j < patient.length; j++)
        {
            sumTemperature += + patient[j];
        }
        sumAve = sumTemperature / patient.length;
        System.out.println();
        System.out.println("Средняя температура по больнице: " + sumAve + " градусов.");
        System.out.println();

        for (int k = 0; k < patient.length; k++){
            if (patient[k] > 36.2 && patient[k] < 36.9){
                kd++;
                System.out.println("Пациент " + (k + 1) + " здоров!");
            }
        }
        System.out.println("Количество здоровых пациентов: " + kd);
    }
}
