public class Rainbow {
    public static void main(String[] args) {
        String text = "Красный оранжевый желтый зеленый голубой синий фиолетовый";
        String [] colors = text.split("\\s+");
        for (int i = 0; i < colors.length; i++) {
            System.out.println(colors[i]);
        }
        System.out.println();
        for (int i = colors.length - 1; i >= 0; i--){
            System.out.println(colors[i]);
        }
    }
}
