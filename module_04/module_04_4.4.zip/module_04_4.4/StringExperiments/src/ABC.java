public class ABC {
    public static void main(String[] args) {
        for (char i = 'A'; i <= 'Z'; i++) {
            int c = i;
            System.out.println(i + ": " + c);
        }
    }
}
