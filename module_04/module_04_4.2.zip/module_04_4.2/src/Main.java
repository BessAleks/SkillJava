public class Main {
    public static void main(String[] args) {
        System.out.println("Минимальное значение числа byte: " + Byte.MIN_VALUE);
        System.out.println("Максимальное значение числа byte: " + Byte.MAX_VALUE);
        System.out.println();
        System.out.println("Минимальное значение числа int: " + Integer.MIN_VALUE);
        System.out.println("Максимальное значение числа int: " + Integer.MAX_VALUE);
        System.out.println();
        System.out.println("Минимальное значение числа short: " + Short.MIN_VALUE);
        System.out.println("Максимальное значение числа short: " + Short.MAX_VALUE);
        System.out.println();
        System.out.println("Минимальное значение числа long: " + Long.MIN_VALUE);
        System.out.println("Максимальное значение числа long: " + Long.MAX_VALUE);
        System.out.println();
        System.out.println("Минимальное значение числа float: " + (-Float.MAX_VALUE));
        System.out.println("Максимальное значение числа float: " + Float.MAX_VALUE);
        System.out.println();
        System.out.println("Минимальное значение числа double: " + (-Double.MAX_VALUE));
        System.out.println("Максимальное значение числа double: " + Double.MAX_VALUE);
        System.out.println();
    }
}
