import java.util.Scanner;

public class Surname {
    public static void main(String[] args) {
        int space = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Введите ФИО:");
        String text = in.nextLine();
        for (char elements : text.toCharArray()) {
            if (elements == ' ') {
                space++;
            }
        }
        if (space == 2) {
            String[] text2 = text.split("\\s");
            for (int i = 0; i < text2.length; i++){
                System.out.println(text2[i]);
            }
        }
        else {
            System.out.println("Введен не корректный формат ФИО!");
        }
    }
}
