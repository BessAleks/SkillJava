import java.util.Scanner;

public class PhoneNumberCleaner {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите телефона в любом формате:");
        String text = in.nextLine();
        String numbers = text.replaceAll("[^0-9]", "");
        if (numbers.length() == 11)
        {
            System.out.println("Формат номера телефона для внесения в БД: " + numbers);
            System.out.println(numbers.charAt(0));
        }
        else {
            System.out.println("Неверно введен номер!");
        }
    }
}
